function getTime()  {
    var url="http://localhost:5500/timeSlot.json"
    // AJAX call to obtain the timing messages
}

function checkAge() {
    //Function to validate Age 
}

function calculateFees() {
    //Function to calculate Final registration fee and Register
}

